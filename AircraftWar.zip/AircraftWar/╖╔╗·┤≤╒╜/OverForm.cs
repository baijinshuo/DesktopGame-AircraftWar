﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 飞机大战
{
    public partial class overForm : Form
    {
        int totalscore;
        int totalenermy;
        int totalhit;
        int totalfire;
        int totalboss;
        Boolean overrestart;
        public int score
        {
            set
            {
                totalscore = value;
            }
        }

        public int enermy
        {
            set
            {
                totalenermy = value;
            }
        }

        public int boss
        {
            set
            {
                totalboss = value;
            }
        }

        public int hit
        {
            set
            {
                totalhit = value;
            }
        }

        public int fire
        {
            set
            {
                totalfire = value;
            }
        }

        public Boolean restart
        {
            get
            {
                return overrestart;
            }
        }
        //以上属性用来传递参数，传递游戏的统计信息，以及用户本窗体的操作，并返回上一窗体
        public overForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            //退出，则restart为假
            this.Close();
            overrestart = false;
        }

        private void restartButton_Click(object sender, EventArgs e)
        {
            //继续则restart为真
            overrestart = true;
            this.Close();
        }

        private void overForm_Load(object sender, EventArgs e)
        {
            scoreLabel.Text = totalscore.ToString();
            enermyLabel.Text = totalenermy.ToString();
            bossLabel.Text = totalboss.ToString();
            ammoLabel.Text = totalfire.ToString();
            if (totalfire == 0)
            {
                hitLabel.Text = "0.00";
            }
            else
            {
                hitLabel.Text = Math.Round(((decimal)totalhit / (decimal)totalfire), 2).ToString();
            }
        }
    }
}
