﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 飞机大战
{
    public partial class WelcomeForm : Form
    {
        public WelcomeForm()
        {
            InitializeComponent();
        } 

        private void startButton_Click(object sender, EventArgs e)
        {
            MainForm mainform = new MainForm();//新建一个游戏界面实体
            this.Visible = false;
            int background = 0;
            int plane = 0;
            if (background1RadioButton.Checked)
            {
                background = 1;
            }
            else if (background2RadioButton.Checked)
            {
                background = 2;
            }
            else if (background3RadioButton.Checked)
            {
                background = 3;
            }
            //选择游戏的背景，并对于background这个变量赋值
            if (j10RadioButton.Checked)
            {
                plane = 1;
            }
            else if(j20RadioButton.Checked)
            {
                plane = 2;
            }
            else if (j31RadioButton.Checked)
            {
                plane = 3;
            }//选择飞机种类
            mainform.plane_m = plane;
            mainform.background_m = background;
            //通过mainform的属性将选择的飞机种类和背景传过去
            mainform.ShowDialog();
            if (mainform.restart == true)
            {
                //当mainform的返回属性restart属性为真时，本窗体重新显示
                this.Visible = true;
            }
            else
            {
                //否则关闭本窗体
                this.Close();
            }
        }
    }
}
