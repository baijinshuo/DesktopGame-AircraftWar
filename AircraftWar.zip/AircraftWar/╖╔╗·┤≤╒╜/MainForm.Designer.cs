﻿namespace 飞机大战
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.timerup = new System.Windows.Forms.Timer(this.components);
            this.timerdown = new System.Windows.Forms.Timer(this.components);
            this.timerleft = new System.Windows.Forms.Timer(this.components);
            this.timerright = new System.Windows.Forms.Timer(this.components);
            this.timermybullet = new System.Windows.Forms.Timer(this.components);
            this.timermybulletflying = new System.Windows.Forms.Timer(this.components);
            this.timerEnemyPlane = new System.Windows.Forms.Timer(this.components);
            this.timerBoss = new System.Windows.Forms.Timer(this.components);
            this.timerEnemyPlaneMove = new System.Windows.Forms.Timer(this.components);
            this.timerEnemyPlaneCrash = new System.Windows.Forms.Timer(this.components);
            this.buJiTimer = new System.Windows.Forms.Timer(this.components);
            this.timerInterval = new System.Windows.Forms.Timer(this.components);
            this.myPlaneCrashTimer = new System.Windows.Forms.Timer(this.components);
            this.bossBulletTimer = new System.Windows.Forms.Timer(this.components);
            this.bossBulletFlyTimer = new System.Windows.Forms.Timer(this.components);
            this.bossPlaneLeftTimer = new System.Windows.Forms.Timer(this.components);
            this.bossPlaneRightTimer = new System.Windows.Forms.Timer(this.components);
            this.lifeLabel = new System.Windows.Forms.Label();
            this.bigBangLabel = new System.Windows.Forms.Label();
            this.moGuYunTimer = new System.Windows.Forms.Timer(this.components);
            this.lostLifeLabel = new System.Windows.Forms.Label();
            this.lostLifeTimer = new System.Windows.Forms.Timer(this.components);
            this.scoreLabel = new System.Windows.Forms.Label();
            this.moGuYunPictureBox = new System.Windows.Forms.PictureBox();
            this.baozhaPictrueBox2 = new System.Windows.Forms.PictureBox();
            this.bossBulletPictureBox10 = new System.Windows.Forms.PictureBox();
            this.bossBulletPictureBox3 = new System.Windows.Forms.PictureBox();
            this.bossBulletPictureBox8 = new System.Windows.Forms.PictureBox();
            this.bossBulletPictureBox6 = new System.Windows.Forms.PictureBox();
            this.bossBulletPictureBox4 = new System.Windows.Forms.PictureBox();
            this.bossBulletPictureBox9 = new System.Windows.Forms.PictureBox();
            this.bossBulletPictureBox7 = new System.Windows.Forms.PictureBox();
            this.bossBulletPictureBox2 = new System.Windows.Forms.PictureBox();
            this.bossBulletPictureBox1 = new System.Windows.Forms.PictureBox();
            this.bossBulletPictureBox5 = new System.Windows.Forms.PictureBox();
            this.bossBulletPictureBox0 = new System.Windows.Forms.PictureBox();
            this.bigBangPictureBox = new System.Windows.Forms.PictureBox();
            this.baoZhaPictureBox = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.enemyPictureBox6 = new System.Windows.Forms.PictureBox();
            this.enemyPictureBox5 = new System.Windows.Forms.PictureBox();
            this.bossPictureBox3 = new System.Windows.Forms.PictureBox();
            this.bossPictureBox2 = new System.Windows.Forms.PictureBox();
            this.enemyPictureBox4 = new System.Windows.Forms.PictureBox();
            this.enemyPictureBox3 = new System.Windows.Forms.PictureBox();
            this.enemyPictureBox2 = new System.Windows.Forms.PictureBox();
            this.enemyPictureBox1 = new System.Windows.Forms.PictureBox();
            this.bossPictureBox1 = new System.Windows.Forms.PictureBox();
            this.myBulletPictureBox9 = new System.Windows.Forms.PictureBox();
            this.myBulletPictureBox8 = new System.Windows.Forms.PictureBox();
            this.myBulletPictureBox7 = new System.Windows.Forms.PictureBox();
            this.myBulletPictureBox6 = new System.Windows.Forms.PictureBox();
            this.myBulletPictureBox5 = new System.Windows.Forms.PictureBox();
            this.myBulletPictureBox4 = new System.Windows.Forms.PictureBox();
            this.myBulletPictureBox3 = new System.Windows.Forms.PictureBox();
            this.myBulletPictureBox2 = new System.Windows.Forms.PictureBox();
            this.myBulletPictureBox1 = new System.Windows.Forms.PictureBox();
            this.myBulletPictureBox0 = new System.Windows.Forms.PictureBox();
            this.j20PictureBox = new System.Windows.Forms.PictureBox();
            this.j31PictureBox = new System.Windows.Forms.PictureBox();
            this.j10PictureBox = new System.Windows.Forms.PictureBox();
            this.background3PictureBox = new System.Windows.Forms.PictureBox();
            this.background2PictureBox = new System.Windows.Forms.PictureBox();
            this.background1PictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.moGuYunPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baozhaPictrueBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bigBangPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.baoZhaPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.j20PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.j31PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.j10PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.background3PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.background2PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.background1PictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // timerup
            // 
            this.timerup.Interval = 10;
            this.timerup.Tick += new System.EventHandler(this.timerup_Tick);
            // 
            // timerdown
            // 
            this.timerdown.Interval = 10;
            this.timerdown.Tick += new System.EventHandler(this.timerdown_Tick);
            // 
            // timerleft
            // 
            this.timerleft.Interval = 10;
            this.timerleft.Tick += new System.EventHandler(this.timerleft_Tick);
            // 
            // timerright
            // 
            this.timerright.Interval = 10;
            this.timerright.Tick += new System.EventHandler(this.timerright_Tick);
            // 
            // timermybullet
            // 
            this.timermybullet.Interval = 50;
            this.timermybullet.Tick += new System.EventHandler(this.timermybullet_Tick);
            // 
            // timermybulletflying
            // 
            this.timermybulletflying.Interval = 20;
            this.timermybulletflying.Tick += new System.EventHandler(this.timermybulletflying_Tick);
            // 
            // timerEnemyPlane
            // 
            this.timerEnemyPlane.Enabled = true;
            this.timerEnemyPlane.Interval = 1000;
            this.timerEnemyPlane.Tick += new System.EventHandler(this.timerEnemyPlane_Tick);
            // 
            // timerBoss
            // 
            this.timerBoss.Enabled = true;
            this.timerBoss.Interval = 5000;
            this.timerBoss.Tick += new System.EventHandler(this.timerBoss_Tick);
            // 
            // timerEnemyPlaneMove
            // 
            this.timerEnemyPlaneMove.Enabled = true;
            this.timerEnemyPlaneMove.Tick += new System.EventHandler(this.timerEnemyPlaneMove_Tick);
            // 
            // timerEnemyPlaneCrash
            // 
            this.timerEnemyPlaneCrash.Enabled = true;
            this.timerEnemyPlaneCrash.Interval = 10;
            this.timerEnemyPlaneCrash.Tick += new System.EventHandler(this.timerEnemyPlaneCrash_Tick);
            // 
            // buJiTimer
            // 
            this.buJiTimer.Enabled = true;
            this.buJiTimer.Interval = 10000;
            this.buJiTimer.Tick += new System.EventHandler(this.buJiTimer_Tick);
            // 
            // timerInterval
            // 
            this.timerInterval.Interval = 10;
            this.timerInterval.Tick += new System.EventHandler(this.timerInterval_Tick);
            // 
            // myPlaneCrashTimer
            // 
            this.myPlaneCrashTimer.Enabled = true;
            this.myPlaneCrashTimer.Interval = 10;
            this.myPlaneCrashTimer.Tick += new System.EventHandler(this.myPlaneCrashTimer_Tick);
            // 
            // bossBulletTimer
            // 
            this.bossBulletTimer.Enabled = true;
            this.bossBulletTimer.Interval = 10;
            this.bossBulletTimer.Tick += new System.EventHandler(this.bossBulletTimer_Tick);
            // 
            // bossBulletFlyTimer
            // 
            this.bossBulletFlyTimer.Interval = 200;
            this.bossBulletFlyTimer.Tick += new System.EventHandler(this.bossBulletFlyTimer_Tick);
            // 
            // bossPlaneLeftTimer
            // 
            this.bossPlaneLeftTimer.Interval = 200;
            this.bossPlaneLeftTimer.Tick += new System.EventHandler(this.bossPlaneLeftTimer_Tick);
            // 
            // bossPlaneRightTimer
            // 
            this.bossPlaneRightTimer.Interval = 200;
            this.bossPlaneRightTimer.Tick += new System.EventHandler(this.bossPlaneRightTimer_Tick);
            // 
            // lifeLabel
            // 
            this.lifeLabel.AutoSize = true;
            this.lifeLabel.BackColor = System.Drawing.Color.Transparent;
            this.lifeLabel.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lifeLabel.ForeColor = System.Drawing.Color.Maroon;
            this.lifeLabel.Location = new System.Drawing.Point(13, 84);
            this.lifeLabel.Name = "lifeLabel";
            this.lifeLabel.Size = new System.Drawing.Size(66, 21);
            this.lifeLabel.TabIndex = 56;
            this.lifeLabel.Text = "Life X 3";
            // 
            // bigBangLabel
            // 
            this.bigBangLabel.AutoSize = true;
            this.bigBangLabel.BackColor = System.Drawing.Color.Transparent;
            this.bigBangLabel.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.bigBangLabel.ForeColor = System.Drawing.Color.Maroon;
            this.bigBangLabel.Location = new System.Drawing.Point(13, 117);
            this.bigBangLabel.Name = "bigBangLabel";
            this.bigBangLabel.Size = new System.Drawing.Size(102, 21);
            this.bigBangLabel.TabIndex = 57;
            this.bigBangLabel.Text = "BigBang X 3";
            // 
            // moGuYunTimer
            // 
            this.moGuYunTimer.Interval = 1000;
            this.moGuYunTimer.Tick += new System.EventHandler(this.moGuYunTimer_Tick);
            // 
            // lostLifeLabel
            // 
            this.lostLifeLabel.AutoSize = true;
            this.lostLifeLabel.BackColor = System.Drawing.Color.Transparent;
            this.lostLifeLabel.Font = new System.Drawing.Font("FZShuTi", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lostLifeLabel.ForeColor = System.Drawing.Color.Maroon;
            this.lostLifeLabel.Location = new System.Drawing.Point(154, 180);
            this.lostLifeLabel.Name = "lostLifeLabel";
            this.lostLifeLabel.Size = new System.Drawing.Size(367, 34);
            this.lostLifeLabel.TabIndex = 54;
            this.lostLifeLabel.Text = "挺住！！再来一发！！！";
            this.lostLifeLabel.Visible = false;
            // 
            // lostLifeTimer
            // 
            this.lostLifeTimer.Interval = 1000;
            this.lostLifeTimer.Tick += new System.EventHandler(this.lostLifeTimer_Tick);
            // 
            // scoreLabel
            // 
            this.scoreLabel.AutoSize = true;
            this.scoreLabel.BackColor = System.Drawing.Color.Transparent;
            this.scoreLabel.Font = new System.Drawing.Font("Microsoft YaHei", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.scoreLabel.ForeColor = System.Drawing.Color.Maroon;
            this.scoreLabel.Location = new System.Drawing.Point(16, 43);
            this.scoreLabel.Name = "scoreLabel";
            this.scoreLabel.Size = new System.Drawing.Size(75, 21);
            this.scoreLabel.TabIndex = 55;
            this.scoreLabel.Text = "Score:  0";
            // 
            // moGuYunPictureBox
            // 
            this.moGuYunPictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.moGuYunPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("moGuYunPictureBox.Image")));
            this.moGuYunPictureBox.Location = new System.Drawing.Point(0, 0);
            this.moGuYunPictureBox.Name = "moGuYunPictureBox";
            this.moGuYunPictureBox.Size = new System.Drawing.Size(739, 619);
            this.moGuYunPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.moGuYunPictureBox.TabIndex = 53;
            this.moGuYunPictureBox.TabStop = false;
            this.moGuYunPictureBox.Visible = false;
            // 
            // baozhaPictrueBox2
            // 
            this.baozhaPictrueBox2.BackColor = System.Drawing.Color.Transparent;
            this.baozhaPictrueBox2.Image = global::飞机大战.Properties.Resources.爆炸;
            this.baozhaPictrueBox2.Location = new System.Drawing.Point(564, 0);
            this.baozhaPictrueBox2.Name = "baozhaPictrueBox2";
            this.baozhaPictrueBox2.Size = new System.Drawing.Size(145, 156);
            this.baozhaPictrueBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.baozhaPictrueBox2.TabIndex = 52;
            this.baozhaPictrueBox2.TabStop = false;
            this.baozhaPictrueBox2.Visible = false;
            // 
            // bossBulletPictureBox10
            // 
            this.bossBulletPictureBox10.BackColor = System.Drawing.Color.Transparent;
            this.bossBulletPictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("bossBulletPictureBox10.Image")));
            this.bossBulletPictureBox10.Location = new System.Drawing.Point(548, 199);
            this.bossBulletPictureBox10.Name = "bossBulletPictureBox10";
            this.bossBulletPictureBox10.Size = new System.Drawing.Size(10, 40);
            this.bossBulletPictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossBulletPictureBox10.TabIndex = 49;
            this.bossBulletPictureBox10.TabStop = false;
            this.bossBulletPictureBox10.Visible = false;
            // 
            // bossBulletPictureBox3
            // 
            this.bossBulletPictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.bossBulletPictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("bossBulletPictureBox3.Image")));
            this.bossBulletPictureBox3.Location = new System.Drawing.Point(423, 199);
            this.bossBulletPictureBox3.Name = "bossBulletPictureBox3";
            this.bossBulletPictureBox3.Size = new System.Drawing.Size(10, 40);
            this.bossBulletPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossBulletPictureBox3.TabIndex = 48;
            this.bossBulletPictureBox3.TabStop = false;
            this.bossBulletPictureBox3.Visible = false;
            // 
            // bossBulletPictureBox8
            // 
            this.bossBulletPictureBox8.BackColor = System.Drawing.Color.Transparent;
            this.bossBulletPictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("bossBulletPictureBox8.Image")));
            this.bossBulletPictureBox8.Location = new System.Drawing.Point(515, 199);
            this.bossBulletPictureBox8.Name = "bossBulletPictureBox8";
            this.bossBulletPictureBox8.Size = new System.Drawing.Size(10, 40);
            this.bossBulletPictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossBulletPictureBox8.TabIndex = 47;
            this.bossBulletPictureBox8.TabStop = false;
            this.bossBulletPictureBox8.Visible = false;
            // 
            // bossBulletPictureBox6
            // 
            this.bossBulletPictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.bossBulletPictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("bossBulletPictureBox6.Image")));
            this.bossBulletPictureBox6.Location = new System.Drawing.Point(469, 199);
            this.bossBulletPictureBox6.Name = "bossBulletPictureBox6";
            this.bossBulletPictureBox6.Size = new System.Drawing.Size(10, 40);
            this.bossBulletPictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossBulletPictureBox6.TabIndex = 46;
            this.bossBulletPictureBox6.TabStop = false;
            this.bossBulletPictureBox6.Visible = false;
            // 
            // bossBulletPictureBox4
            // 
            this.bossBulletPictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.bossBulletPictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("bossBulletPictureBox4.Image")));
            this.bossBulletPictureBox4.Location = new System.Drawing.Point(437, 199);
            this.bossBulletPictureBox4.Name = "bossBulletPictureBox4";
            this.bossBulletPictureBox4.Size = new System.Drawing.Size(10, 40);
            this.bossBulletPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossBulletPictureBox4.TabIndex = 45;
            this.bossBulletPictureBox4.TabStop = false;
            this.bossBulletPictureBox4.Visible = false;
            // 
            // bossBulletPictureBox9
            // 
            this.bossBulletPictureBox9.BackColor = System.Drawing.Color.Transparent;
            this.bossBulletPictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("bossBulletPictureBox9.Image")));
            this.bossBulletPictureBox9.Location = new System.Drawing.Point(531, 199);
            this.bossBulletPictureBox9.Name = "bossBulletPictureBox9";
            this.bossBulletPictureBox9.Size = new System.Drawing.Size(10, 40);
            this.bossBulletPictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossBulletPictureBox9.TabIndex = 39;
            this.bossBulletPictureBox9.TabStop = false;
            this.bossBulletPictureBox9.Visible = false;
            // 
            // bossBulletPictureBox7
            // 
            this.bossBulletPictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.bossBulletPictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("bossBulletPictureBox7.Image")));
            this.bossBulletPictureBox7.Location = new System.Drawing.Point(495, 199);
            this.bossBulletPictureBox7.Name = "bossBulletPictureBox7";
            this.bossBulletPictureBox7.Size = new System.Drawing.Size(10, 40);
            this.bossBulletPictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossBulletPictureBox7.TabIndex = 38;
            this.bossBulletPictureBox7.TabStop = false;
            this.bossBulletPictureBox7.Visible = false;
            // 
            // bossBulletPictureBox2
            // 
            this.bossBulletPictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.bossBulletPictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("bossBulletPictureBox2.Image")));
            this.bossBulletPictureBox2.Location = new System.Drawing.Point(402, 199);
            this.bossBulletPictureBox2.Name = "bossBulletPictureBox2";
            this.bossBulletPictureBox2.Size = new System.Drawing.Size(10, 40);
            this.bossBulletPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossBulletPictureBox2.TabIndex = 37;
            this.bossBulletPictureBox2.TabStop = false;
            this.bossBulletPictureBox2.Visible = false;
            // 
            // bossBulletPictureBox1
            // 
            this.bossBulletPictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.bossBulletPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("bossBulletPictureBox1.Image")));
            this.bossBulletPictureBox1.Location = new System.Drawing.Point(378, 199);
            this.bossBulletPictureBox1.Name = "bossBulletPictureBox1";
            this.bossBulletPictureBox1.Size = new System.Drawing.Size(10, 40);
            this.bossBulletPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossBulletPictureBox1.TabIndex = 36;
            this.bossBulletPictureBox1.TabStop = false;
            this.bossBulletPictureBox1.Visible = false;
            // 
            // bossBulletPictureBox5
            // 
            this.bossBulletPictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.bossBulletPictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("bossBulletPictureBox5.Image")));
            this.bossBulletPictureBox5.Location = new System.Drawing.Point(453, 199);
            this.bossBulletPictureBox5.Name = "bossBulletPictureBox5";
            this.bossBulletPictureBox5.Size = new System.Drawing.Size(10, 40);
            this.bossBulletPictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossBulletPictureBox5.TabIndex = 35;
            this.bossBulletPictureBox5.TabStop = false;
            this.bossBulletPictureBox5.Visible = false;
            // 
            // bossBulletPictureBox0
            // 
            this.bossBulletPictureBox0.BackColor = System.Drawing.Color.Transparent;
            this.bossBulletPictureBox0.Image = ((System.Drawing.Image)(resources.GetObject("bossBulletPictureBox0.Image")));
            this.bossBulletPictureBox0.Location = new System.Drawing.Point(339, 199);
            this.bossBulletPictureBox0.Name = "bossBulletPictureBox0";
            this.bossBulletPictureBox0.Size = new System.Drawing.Size(10, 40);
            this.bossBulletPictureBox0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossBulletPictureBox0.TabIndex = 34;
            this.bossBulletPictureBox0.TabStop = false;
            this.bossBulletPictureBox0.Visible = false;
            // 
            // bigBangPictureBox
            // 
            this.bigBangPictureBox.BackColor = System.Drawing.Color.Transparent;
            this.bigBangPictureBox.Image = global::飞机大战.Properties.Resources.补给箱;
            this.bigBangPictureBox.Location = new System.Drawing.Point(97, 268);
            this.bigBangPictureBox.Name = "bigBangPictureBox";
            this.bigBangPictureBox.Size = new System.Drawing.Size(40, 33);
            this.bigBangPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bigBangPictureBox.TabIndex = 33;
            this.bigBangPictureBox.TabStop = false;
            this.bigBangPictureBox.Visible = false;
            // 
            // baoZhaPictureBox
            // 
            this.baoZhaPictureBox.BackColor = System.Drawing.Color.Transparent;
            this.baoZhaPictureBox.Image = global::飞机大战.Properties.Resources.爆炸;
            this.baoZhaPictureBox.Location = new System.Drawing.Point(80, 159);
            this.baoZhaPictureBox.Name = "baoZhaPictureBox";
            this.baoZhaPictureBox.Size = new System.Drawing.Size(57, 50);
            this.baoZhaPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.baoZhaPictureBox.TabIndex = 32;
            this.baoZhaPictureBox.TabStop = false;
            this.baoZhaPictureBox.Visible = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox7.Image = global::飞机大战.Properties.Resources.X_36;
            this.pictureBox7.Location = new System.Drawing.Point(637, 291);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(50, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 31;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Visible = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox6.Image = global::飞机大战.Properties.Resources.FA_18大黄蜂战斗攻击机;
            this.pictureBox6.Location = new System.Drawing.Point(564, 279);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(51, 50);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 30;
            this.pictureBox6.TabStop = false;
            this.pictureBox6.Visible = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox5.Image = global::飞机大战.Properties.Resources.F_4_幻影II型;
            this.pictureBox5.Location = new System.Drawing.Point(481, 280);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(60, 61);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 29;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox4.Image = global::飞机大战.Properties.Resources.F_4_幻影II型;
            this.pictureBox4.Location = new System.Drawing.Point(193, 268);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(60, 61);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 28;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::飞机大战.Properties.Resources.F_22_猛禽;
            this.pictureBox3.Location = new System.Drawing.Point(402, 277);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(61, 64);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 27;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::飞机大战.Properties.Resources.F_117夜鹰隐身战斗轰炸机;
            this.pictureBox2.Location = new System.Drawing.Point(263, 268);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(62, 61);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 26;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::飞机大战.Properties.Resources.F_35B;
            this.pictureBox1.Location = new System.Drawing.Point(105, 307);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(54, 64);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 25;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // enemyPictureBox6
            // 
            this.enemyPictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.enemyPictureBox6.Image = global::飞机大战.Properties.Resources.X_36;
            this.enemyPictureBox6.Location = new System.Drawing.Point(166, 127);
            this.enemyPictureBox6.Name = "enemyPictureBox6";
            this.enemyPictureBox6.Size = new System.Drawing.Size(50, 50);
            this.enemyPictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyPictureBox6.TabIndex = 24;
            this.enemyPictureBox6.TabStop = false;
            this.enemyPictureBox6.Visible = false;
            // 
            // enemyPictureBox5
            // 
            this.enemyPictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.enemyPictureBox5.Image = global::飞机大战.Properties.Resources.FA_18大黄蜂战斗攻击机;
            this.enemyPictureBox5.Location = new System.Drawing.Point(165, 70);
            this.enemyPictureBox5.Name = "enemyPictureBox5";
            this.enemyPictureBox5.Size = new System.Drawing.Size(51, 50);
            this.enemyPictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyPictureBox5.TabIndex = 23;
            this.enemyPictureBox5.TabStop = false;
            this.enemyPictureBox5.Visible = false;
            // 
            // bossPictureBox3
            // 
            this.bossPictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.bossPictureBox3.Image = global::飞机大战.Properties.Resources.BOSS;
            this.bossPictureBox3.Location = new System.Drawing.Point(574, 0);
            this.bossPictureBox3.Name = "bossPictureBox3";
            this.bossPictureBox3.Size = new System.Drawing.Size(140, 156);
            this.bossPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossPictureBox3.TabIndex = 22;
            this.bossPictureBox3.TabStop = false;
            this.bossPictureBox3.Visible = false;
            // 
            // bossPictureBox2
            // 
            this.bossPictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.bossPictureBox2.Image = global::飞机大战.Properties.Resources.boss2;
            this.bossPictureBox2.Location = new System.Drawing.Point(427, 0);
            this.bossPictureBox2.Name = "bossPictureBox2";
            this.bossPictureBox2.Size = new System.Drawing.Size(145, 153);
            this.bossPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossPictureBox2.TabIndex = 21;
            this.bossPictureBox2.TabStop = false;
            this.bossPictureBox2.Visible = false;
            // 
            // enemyPictureBox4
            // 
            this.enemyPictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.enemyPictureBox4.Image = global::飞机大战.Properties.Resources.F_4_幻影II型;
            this.enemyPictureBox4.Location = new System.Drawing.Point(207, 3);
            this.enemyPictureBox4.Name = "enemyPictureBox4";
            this.enemyPictureBox4.Size = new System.Drawing.Size(60, 61);
            this.enemyPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyPictureBox4.TabIndex = 20;
            this.enemyPictureBox4.TabStop = false;
            this.enemyPictureBox4.Visible = false;
            // 
            // enemyPictureBox3
            // 
            this.enemyPictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.enemyPictureBox3.Image = global::飞机大战.Properties.Resources.F_35B;
            this.enemyPictureBox3.Location = new System.Drawing.Point(37, 0);
            this.enemyPictureBox3.Name = "enemyPictureBox3";
            this.enemyPictureBox3.Size = new System.Drawing.Size(54, 64);
            this.enemyPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyPictureBox3.TabIndex = 19;
            this.enemyPictureBox3.TabStop = false;
            this.enemyPictureBox3.Visible = false;
            // 
            // enemyPictureBox2
            // 
            this.enemyPictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.enemyPictureBox2.Image = global::飞机大战.Properties.Resources.F_22_猛禽;
            this.enemyPictureBox2.Location = new System.Drawing.Point(165, 0);
            this.enemyPictureBox2.Name = "enemyPictureBox2";
            this.enemyPictureBox2.Size = new System.Drawing.Size(61, 64);
            this.enemyPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyPictureBox2.TabIndex = 18;
            this.enemyPictureBox2.TabStop = false;
            this.enemyPictureBox2.Visible = false;
            // 
            // enemyPictureBox1
            // 
            this.enemyPictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.enemyPictureBox1.Image = global::飞机大战.Properties.Resources.F_117夜鹰隐身战斗轰炸机;
            this.enemyPictureBox1.Location = new System.Drawing.Point(97, 3);
            this.enemyPictureBox1.Name = "enemyPictureBox1";
            this.enemyPictureBox1.Size = new System.Drawing.Size(62, 61);
            this.enemyPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.enemyPictureBox1.TabIndex = 17;
            this.enemyPictureBox1.TabStop = false;
            this.enemyPictureBox1.Visible = false;
            // 
            // bossPictureBox1
            // 
            this.bossPictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.bossPictureBox1.Image = global::飞机大战.Properties.Resources.boss3;
            this.bossPictureBox1.Location = new System.Drawing.Point(273, -3);
            this.bossPictureBox1.Name = "bossPictureBox1";
            this.bossPictureBox1.Size = new System.Drawing.Size(148, 156);
            this.bossPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bossPictureBox1.TabIndex = 16;
            this.bossPictureBox1.TabStop = false;
            this.bossPictureBox1.Visible = false;
            // 
            // myBulletPictureBox9
            // 
            this.myBulletPictureBox9.BackColor = System.Drawing.Color.Transparent;
            this.myBulletPictureBox9.Image = global::飞机大战.Properties.Resources.子弹;
            this.myBulletPictureBox9.Location = new System.Drawing.Point(459, 379);
            this.myBulletPictureBox9.Name = "myBulletPictureBox9";
            this.myBulletPictureBox9.Size = new System.Drawing.Size(10, 40);
            this.myBulletPictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myBulletPictureBox9.TabIndex = 15;
            this.myBulletPictureBox9.TabStop = false;
            this.myBulletPictureBox9.Visible = false;
            // 
            // myBulletPictureBox8
            // 
            this.myBulletPictureBox8.BackColor = System.Drawing.Color.Transparent;
            this.myBulletPictureBox8.Image = global::飞机大战.Properties.Resources.子弹;
            this.myBulletPictureBox8.Location = new System.Drawing.Point(435, 379);
            this.myBulletPictureBox8.Name = "myBulletPictureBox8";
            this.myBulletPictureBox8.Size = new System.Drawing.Size(10, 40);
            this.myBulletPictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myBulletPictureBox8.TabIndex = 14;
            this.myBulletPictureBox8.TabStop = false;
            this.myBulletPictureBox8.Visible = false;
            // 
            // myBulletPictureBox7
            // 
            this.myBulletPictureBox7.BackColor = System.Drawing.Color.Transparent;
            this.myBulletPictureBox7.Image = global::飞机大战.Properties.Resources.子弹;
            this.myBulletPictureBox7.Location = new System.Drawing.Point(411, 379);
            this.myBulletPictureBox7.Name = "myBulletPictureBox7";
            this.myBulletPictureBox7.Size = new System.Drawing.Size(10, 40);
            this.myBulletPictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myBulletPictureBox7.TabIndex = 13;
            this.myBulletPictureBox7.TabStop = false;
            this.myBulletPictureBox7.Visible = false;
            // 
            // myBulletPictureBox6
            // 
            this.myBulletPictureBox6.BackColor = System.Drawing.Color.Transparent;
            this.myBulletPictureBox6.Image = global::飞机大战.Properties.Resources.子弹;
            this.myBulletPictureBox6.Location = new System.Drawing.Point(387, 379);
            this.myBulletPictureBox6.Name = "myBulletPictureBox6";
            this.myBulletPictureBox6.Size = new System.Drawing.Size(10, 40);
            this.myBulletPictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myBulletPictureBox6.TabIndex = 12;
            this.myBulletPictureBox6.TabStop = false;
            this.myBulletPictureBox6.Visible = false;
            // 
            // myBulletPictureBox5
            // 
            this.myBulletPictureBox5.BackColor = System.Drawing.Color.Transparent;
            this.myBulletPictureBox5.Image = global::飞机大战.Properties.Resources.子弹;
            this.myBulletPictureBox5.Location = new System.Drawing.Point(363, 379);
            this.myBulletPictureBox5.Name = "myBulletPictureBox5";
            this.myBulletPictureBox5.Size = new System.Drawing.Size(10, 40);
            this.myBulletPictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myBulletPictureBox5.TabIndex = 11;
            this.myBulletPictureBox5.TabStop = false;
            this.myBulletPictureBox5.Visible = false;
            // 
            // myBulletPictureBox4
            // 
            this.myBulletPictureBox4.BackColor = System.Drawing.Color.Transparent;
            this.myBulletPictureBox4.Image = global::飞机大战.Properties.Resources.子弹;
            this.myBulletPictureBox4.Location = new System.Drawing.Point(339, 379);
            this.myBulletPictureBox4.Name = "myBulletPictureBox4";
            this.myBulletPictureBox4.Size = new System.Drawing.Size(10, 40);
            this.myBulletPictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myBulletPictureBox4.TabIndex = 10;
            this.myBulletPictureBox4.TabStop = false;
            this.myBulletPictureBox4.Visible = false;
            // 
            // myBulletPictureBox3
            // 
            this.myBulletPictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.myBulletPictureBox3.Image = global::飞机大战.Properties.Resources.子弹;
            this.myBulletPictureBox3.Location = new System.Drawing.Point(315, 379);
            this.myBulletPictureBox3.Name = "myBulletPictureBox3";
            this.myBulletPictureBox3.Size = new System.Drawing.Size(10, 40);
            this.myBulletPictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myBulletPictureBox3.TabIndex = 9;
            this.myBulletPictureBox3.TabStop = false;
            this.myBulletPictureBox3.Visible = false;
            // 
            // myBulletPictureBox2
            // 
            this.myBulletPictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.myBulletPictureBox2.Image = global::飞机大战.Properties.Resources.子弹;
            this.myBulletPictureBox2.Location = new System.Drawing.Point(291, 379);
            this.myBulletPictureBox2.Name = "myBulletPictureBox2";
            this.myBulletPictureBox2.Size = new System.Drawing.Size(10, 40);
            this.myBulletPictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myBulletPictureBox2.TabIndex = 8;
            this.myBulletPictureBox2.TabStop = false;
            this.myBulletPictureBox2.Visible = false;
            // 
            // myBulletPictureBox1
            // 
            this.myBulletPictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.myBulletPictureBox1.Image = global::飞机大战.Properties.Resources.子弹;
            this.myBulletPictureBox1.Location = new System.Drawing.Point(267, 379);
            this.myBulletPictureBox1.Name = "myBulletPictureBox1";
            this.myBulletPictureBox1.Size = new System.Drawing.Size(10, 40);
            this.myBulletPictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myBulletPictureBox1.TabIndex = 7;
            this.myBulletPictureBox1.TabStop = false;
            this.myBulletPictureBox1.Visible = false;
            // 
            // myBulletPictureBox0
            // 
            this.myBulletPictureBox0.BackColor = System.Drawing.Color.Transparent;
            this.myBulletPictureBox0.Image = global::飞机大战.Properties.Resources.子弹;
            this.myBulletPictureBox0.Location = new System.Drawing.Point(243, 379);
            this.myBulletPictureBox0.Name = "myBulletPictureBox0";
            this.myBulletPictureBox0.Size = new System.Drawing.Size(10, 40);
            this.myBulletPictureBox0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.myBulletPictureBox0.TabIndex = 6;
            this.myBulletPictureBox0.TabStop = false;
            this.myBulletPictureBox0.Visible = false;
            // 
            // j20PictureBox
            // 
            this.j20PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.j20PictureBox.Image = global::飞机大战.Properties.Resources.歼_20;
            this.j20PictureBox.Location = new System.Drawing.Point(363, 512);
            this.j20PictureBox.Name = "j20PictureBox";
            this.j20PictureBox.Size = new System.Drawing.Size(51, 95);
            this.j20PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.j20PictureBox.TabIndex = 5;
            this.j20PictureBox.TabStop = false;
            this.j20PictureBox.Visible = false;
            // 
            // j31PictureBox
            // 
            this.j31PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.j31PictureBox.Image = global::飞机大战.Properties.Resources.歼_31;
            this.j31PictureBox.Location = new System.Drawing.Point(363, 512);
            this.j31PictureBox.Name = "j31PictureBox";
            this.j31PictureBox.Size = new System.Drawing.Size(51, 95);
            this.j31PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.j31PictureBox.TabIndex = 4;
            this.j31PictureBox.TabStop = false;
            this.j31PictureBox.Visible = false;
            // 
            // j10PictureBox
            // 
            this.j10PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.j10PictureBox.Image = global::飞机大战.Properties.Resources.歼_101;
            this.j10PictureBox.Location = new System.Drawing.Point(363, 512);
            this.j10PictureBox.Name = "j10PictureBox";
            this.j10PictureBox.Size = new System.Drawing.Size(51, 95);
            this.j10PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.j10PictureBox.TabIndex = 3;
            this.j10PictureBox.TabStop = false;
            this.j10PictureBox.Visible = false;
            // 
            // background3PictureBox
            // 
            this.background3PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.background3PictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.background3PictureBox.Image = global::飞机大战.Properties.Resources._3648835_190608008249_21;
            this.background3PictureBox.Location = new System.Drawing.Point(0, 0);
            this.background3PictureBox.Name = "background3PictureBox";
            this.background3PictureBox.Size = new System.Drawing.Size(739, 619);
            this.background3PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.background3PictureBox.TabIndex = 2;
            this.background3PictureBox.TabStop = false;
            this.background3PictureBox.Visible = false;
            // 
            // background2PictureBox
            // 
            this.background2PictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.background2PictureBox.Image = global::飞机大战.Properties.Resources._14132;
            this.background2PictureBox.Location = new System.Drawing.Point(0, 0);
            this.background2PictureBox.Name = "background2PictureBox";
            this.background2PictureBox.Size = new System.Drawing.Size(739, 619);
            this.background2PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.background2PictureBox.TabIndex = 1;
            this.background2PictureBox.TabStop = false;
            this.background2PictureBox.Visible = false;
            // 
            // background1PictureBox
            // 
            this.background1PictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.background1PictureBox.Image = global::飞机大战.Properties.Resources._200891981924404_2;
            this.background1PictureBox.Location = new System.Drawing.Point(0, 0);
            this.background1PictureBox.Name = "background1PictureBox";
            this.background1PictureBox.Size = new System.Drawing.Size(739, 619);
            this.background1PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.background1PictureBox.TabIndex = 0;
            this.background1PictureBox.TabStop = false;
            this.background1PictureBox.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(739, 619);
            this.Controls.Add(this.moGuYunPictureBox);
            this.Controls.Add(this.scoreLabel);
            this.Controls.Add(this.lifeLabel);
            this.Controls.Add(this.bigBangLabel);
            this.Controls.Add(this.lostLifeLabel);
            this.Controls.Add(this.baozhaPictrueBox2);
            this.Controls.Add(this.bossBulletPictureBox10);
            this.Controls.Add(this.bossBulletPictureBox3);
            this.Controls.Add(this.bossBulletPictureBox8);
            this.Controls.Add(this.bossBulletPictureBox6);
            this.Controls.Add(this.bossBulletPictureBox4);
            this.Controls.Add(this.bossBulletPictureBox9);
            this.Controls.Add(this.bossBulletPictureBox7);
            this.Controls.Add(this.bossBulletPictureBox2);
            this.Controls.Add(this.bossBulletPictureBox1);
            this.Controls.Add(this.bossBulletPictureBox5);
            this.Controls.Add(this.bossBulletPictureBox0);
            this.Controls.Add(this.bigBangPictureBox);
            this.Controls.Add(this.baoZhaPictureBox);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.enemyPictureBox6);
            this.Controls.Add(this.enemyPictureBox5);
            this.Controls.Add(this.bossPictureBox3);
            this.Controls.Add(this.bossPictureBox2);
            this.Controls.Add(this.enemyPictureBox4);
            this.Controls.Add(this.enemyPictureBox3);
            this.Controls.Add(this.enemyPictureBox2);
            this.Controls.Add(this.enemyPictureBox1);
            this.Controls.Add(this.bossPictureBox1);
            this.Controls.Add(this.myBulletPictureBox9);
            this.Controls.Add(this.myBulletPictureBox8);
            this.Controls.Add(this.myBulletPictureBox7);
            this.Controls.Add(this.myBulletPictureBox6);
            this.Controls.Add(this.myBulletPictureBox5);
            this.Controls.Add(this.myBulletPictureBox4);
            this.Controls.Add(this.myBulletPictureBox3);
            this.Controls.Add(this.myBulletPictureBox2);
            this.Controls.Add(this.myBulletPictureBox1);
            this.Controls.Add(this.myBulletPictureBox0);
            this.Controls.Add(this.j20PictureBox);
            this.Controls.Add(this.j31PictureBox);
            this.Controls.Add(this.j10PictureBox);
            this.Controls.Add(this.background3PictureBox);
            this.Controls.Add(this.background2PictureBox);
            this.Controls.Add(this.background1PictureBox);
            this.ForeColor = System.Drawing.SystemColors.Control;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "打飞机";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.MainForm_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.moGuYunPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baozhaPictrueBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossBulletPictureBox0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bigBangPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.baoZhaPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemyPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bossPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.myBulletPictureBox0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.j20PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.j31PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.j10PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.background3PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.background2PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.background1PictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox background1PictureBox;
        private System.Windows.Forms.PictureBox background2PictureBox;
        private System.Windows.Forms.PictureBox j10PictureBox;
        private System.Windows.Forms.PictureBox j31PictureBox;
        private System.Windows.Forms.PictureBox j20PictureBox;
        private System.Windows.Forms.Timer timerup;
        private System.Windows.Forms.Timer timerdown;
        private System.Windows.Forms.Timer timerleft;
        private System.Windows.Forms.Timer timerright;
        private System.Windows.Forms.PictureBox myBulletPictureBox0;
        private System.Windows.Forms.PictureBox myBulletPictureBox1;
        private System.Windows.Forms.PictureBox myBulletPictureBox2;
        private System.Windows.Forms.PictureBox myBulletPictureBox3;
        private System.Windows.Forms.PictureBox myBulletPictureBox4;
        private System.Windows.Forms.PictureBox myBulletPictureBox5;
        private System.Windows.Forms.PictureBox myBulletPictureBox6;
        private System.Windows.Forms.PictureBox myBulletPictureBox7;
        private System.Windows.Forms.PictureBox myBulletPictureBox8;
        private System.Windows.Forms.PictureBox myBulletPictureBox9;
        private System.Windows.Forms.Timer timermybullet;
        private System.Windows.Forms.Timer timermybulletflying;
        private System.Windows.Forms.PictureBox bossPictureBox1;
        private System.Windows.Forms.PictureBox enemyPictureBox1;
        private System.Windows.Forms.PictureBox enemyPictureBox2;
        private System.Windows.Forms.PictureBox enemyPictureBox3;
        private System.Windows.Forms.PictureBox enemyPictureBox4;
        private System.Windows.Forms.PictureBox bossPictureBox2;
        private System.Windows.Forms.PictureBox bossPictureBox3;
        private System.Windows.Forms.Timer timerEnemyPlane;
        private System.Windows.Forms.Timer timerBoss;
        private System.Windows.Forms.PictureBox enemyPictureBox5;
        private System.Windows.Forms.PictureBox enemyPictureBox6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Timer timerEnemyPlaneMove;
        private System.Windows.Forms.PictureBox baoZhaPictureBox;
        private System.Windows.Forms.Timer timerEnemyPlaneCrash;
        private System.Windows.Forms.PictureBox bigBangPictureBox;
        private System.Windows.Forms.Timer buJiTimer;
        private System.Windows.Forms.Timer timerInterval;
        private System.Windows.Forms.PictureBox bossBulletPictureBox0;
        private System.Windows.Forms.PictureBox bossBulletPictureBox5;
        private System.Windows.Forms.PictureBox bossBulletPictureBox1;
        private System.Windows.Forms.PictureBox bossBulletPictureBox2;
        private System.Windows.Forms.PictureBox bossBulletPictureBox7;
        private System.Windows.Forms.PictureBox bossBulletPictureBox9;
        private System.Windows.Forms.PictureBox bossBulletPictureBox4;
        private System.Windows.Forms.PictureBox bossBulletPictureBox6;
        private System.Windows.Forms.PictureBox bossBulletPictureBox8;
        private System.Windows.Forms.PictureBox bossBulletPictureBox3;
        private System.Windows.Forms.PictureBox bossBulletPictureBox10;
        private System.Windows.Forms.PictureBox background3PictureBox;
        private System.Windows.Forms.Timer myPlaneCrashTimer;
        private System.Windows.Forms.Timer bossBulletTimer;
        private System.Windows.Forms.Timer bossBulletFlyTimer;
        private System.Windows.Forms.Timer bossPlaneLeftTimer;
        private System.Windows.Forms.Timer bossPlaneRightTimer;
        private System.Windows.Forms.Label lifeLabel;
        private System.Windows.Forms.Label bigBangLabel;
        private System.Windows.Forms.PictureBox baozhaPictrueBox2;
        private System.Windows.Forms.Timer moGuYunTimer;
        private System.Windows.Forms.Label lostLifeLabel;
        private System.Windows.Forms.Timer lostLifeTimer;
        private System.Windows.Forms.Label scoreLabel;
        private System.Windows.Forms.PictureBox moGuYunPictureBox;
    }
}