﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 飞机大战
{
    public partial class overForm : Form
    {
        int totalscore;
        int totalenermy;
        public int score
        {
            set
            {
                totalscore = value;
            }
        }

        public int enermy
        {
            set
            {
                totalenermy = value;
            }
        }

        public overForm()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
