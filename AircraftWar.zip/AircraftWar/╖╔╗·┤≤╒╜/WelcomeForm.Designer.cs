﻿namespace 飞机大战
{
    partial class WelcomeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WelcomeForm));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.background3RadioButton = new System.Windows.Forms.RadioButton();
            this.background2RadioButton = new System.Windows.Forms.RadioButton();
            this.background1RadioButton = new System.Windows.Forms.RadioButton();
            this.startButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.j31RadioButton = new System.Windows.Forms.RadioButton();
            this.j20RadioButton = new System.Windows.Forms.RadioButton();
            this.j10RadioButton = new System.Windows.Forms.RadioButton();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.background3RadioButton);
            this.groupBox1.Controls.Add(this.background2RadioButton);
            this.groupBox1.Controls.Add(this.background1RadioButton);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(38, 79);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(122, 178);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "选择场景";
            // 
            // background3RadioButton
            // 
            this.background3RadioButton.BackColor = System.Drawing.Color.Transparent;
            this.background3RadioButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.background3RadioButton.ForeColor = System.Drawing.Color.Lime;
            this.background3RadioButton.Location = new System.Drawing.Point(22, 134);
            this.background3RadioButton.Name = "background3RadioButton";
            this.background3RadioButton.Size = new System.Drawing.Size(65, 18);
            this.background3RadioButton.TabIndex = 2;
            this.background3RadioButton.Text = "雨林";
            this.background3RadioButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.background3RadioButton.UseVisualStyleBackColor = false;
            // 
            // background2RadioButton
            // 
            this.background2RadioButton.BackColor = System.Drawing.Color.Transparent;
            this.background2RadioButton.ForeColor = System.Drawing.Color.DarkOrange;
            this.background2RadioButton.Location = new System.Drawing.Point(22, 85);
            this.background2RadioButton.Name = "background2RadioButton";
            this.background2RadioButton.Size = new System.Drawing.Size(65, 18);
            this.background2RadioButton.TabIndex = 1;
            this.background2RadioButton.Text = "沙漠";
            this.background2RadioButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.background2RadioButton.UseVisualStyleBackColor = false;
            // 
            // background1RadioButton
            // 
            this.background1RadioButton.BackColor = System.Drawing.Color.Transparent;
            this.background1RadioButton.Checked = true;
            this.background1RadioButton.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.background1RadioButton.Location = new System.Drawing.Point(22, 36);
            this.background1RadioButton.Name = "background1RadioButton";
            this.background1RadioButton.Size = new System.Drawing.Size(65, 18);
            this.background1RadioButton.TabIndex = 0;
            this.background1RadioButton.TabStop = true;
            this.background1RadioButton.Text = "海洋";
            this.background1RadioButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.background1RadioButton.UseVisualStyleBackColor = false;
            // 
            // startButton
            // 
            this.startButton.BackColor = System.Drawing.Color.Transparent;
            this.startButton.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.startButton.ForeColor = System.Drawing.Color.White;
            this.startButton.Location = new System.Drawing.Point(38, 333);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(99, 27);
            this.startButton.TabIndex = 1;
            this.startButton.Text = "开始游戏";
            this.startButton.UseVisualStyleBackColor = false;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.Transparent;
            this.groupBox2.Controls.Add(this.j31RadioButton);
            this.groupBox2.Controls.Add(this.j20RadioButton);
            this.groupBox2.Controls.Add(this.j10RadioButton);
            this.groupBox2.Controls.Add(this.pictureBox3);
            this.groupBox2.Controls.Add(this.pictureBox2);
            this.groupBox2.Controls.Add(this.pictureBox1);
            this.groupBox2.Location = new System.Drawing.Point(211, 50);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(617, 260);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "选择战机";
            // 
            // j31RadioButton
            // 
            this.j31RadioButton.BackColor = System.Drawing.Color.Transparent;
            this.j31RadioButton.Font = new System.Drawing.Font("YouYuan", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.j31RadioButton.Location = new System.Drawing.Point(456, 213);
            this.j31RadioButton.Name = "j31RadioButton";
            this.j31RadioButton.Size = new System.Drawing.Size(132, 18);
            this.j31RadioButton.TabIndex = 8;
            this.j31RadioButton.Text = "歼31战斗机";
            this.j31RadioButton.UseVisualStyleBackColor = false;
            // 
            // j20RadioButton
            // 
            this.j20RadioButton.BackColor = System.Drawing.Color.Transparent;
            this.j20RadioButton.Font = new System.Drawing.Font("YouYuan", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.j20RadioButton.Location = new System.Drawing.Point(233, 213);
            this.j20RadioButton.Name = "j20RadioButton";
            this.j20RadioButton.Size = new System.Drawing.Size(132, 18);
            this.j20RadioButton.TabIndex = 7;
            this.j20RadioButton.Text = "歼20战斗机";
            this.j20RadioButton.UseVisualStyleBackColor = false;
            // 
            // j10RadioButton
            // 
            this.j10RadioButton.BackColor = System.Drawing.Color.Transparent;
            this.j10RadioButton.Checked = true;
            this.j10RadioButton.Font = new System.Drawing.Font("YouYuan", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.j10RadioButton.Location = new System.Drawing.Point(25, 213);
            this.j10RadioButton.Name = "j10RadioButton";
            this.j10RadioButton.Size = new System.Drawing.Size(132, 18);
            this.j10RadioButton.TabIndex = 6;
            this.j10RadioButton.TabStop = true;
            this.j10RadioButton.Text = "歼10-B战斗机";
            this.j10RadioButton.UseVisualStyleBackColor = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox3.Image = global::飞机大战.Properties.Resources.歼_31;
            this.pictureBox3.Location = new System.Drawing.Point(456, 36);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(132, 171);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::飞机大战.Properties.Resources.歼_20;
            this.pictureBox2.Location = new System.Drawing.Point(233, 36);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(132, 171);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::飞机大战.Properties.Resources.歼_10;
            this.pictureBox1.Location = new System.Drawing.Point(25, 36);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(132, 171);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // WelcomeForm
            // 
            this.AcceptButton = this.startButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::飞机大战.Properties.Resources.start;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(897, 463);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("STXinwei", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "WelcomeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "打飞机";
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton background3RadioButton;
        private System.Windows.Forms.RadioButton background2RadioButton;
        private System.Windows.Forms.RadioButton background1RadioButton;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.RadioButton j20RadioButton;
        private System.Windows.Forms.RadioButton j10RadioButton;
        private System.Windows.Forms.RadioButton j31RadioButton;

        public System.EventHandler RadioButton_CheckedChanged { get; set; }
    }
}

