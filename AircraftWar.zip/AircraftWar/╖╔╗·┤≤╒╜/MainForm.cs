﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
/*实验分工：陈斌和王岩主要负责代码的书写，界面的设计。应卓尔和刘元哲主要负责众多素材的搜集，PPT的制作以及文档的制作。
  实验前期：
  前期我们对于游戏的选定出现了分歧。有人想写华容道，有人想写飞机大战。最后我们本真突出实验的“高大上”的原则，毅然决然的选择了打飞机。
  可以说选了这个题目的时候我们一点思路都没有不知道怎么实现飞机的移动，炮弹的发射，等等一系列的问题。我们最后在网上找到了一个非常简单的
  飞机大战的一个程序，它只是实现了飞机的移动和发射子弹。我们根据这个小的程序。熟练掌握了timer的应用，然后写出了这个不算很简单的程序。
  实验中期：
  实验的书写可以说是最最痛苦的事情了，一个小小的timer把我弄晕了好几天，什么stop、什么start、什么enable、什么Interval之类的，因为当时这部分不是‘
  学习的重点，所以我们就是对这个不太清楚。然后上网查资料，问同学。记忆最深刻的就是一开始飞机移动的时候带有白色的底边，不动的时候是正常的。这个
  问题真的快把我们都弄得疯掉了。网上也找不到关于这个问题的解决方法。我们弄了整整3天，最后我们创造性的想到了利用画布的效果抵挡白边的效果。
  最终解决了这个问题。
  实验后期：
  实验的整体框架完成之后，实验的后期工作也是很重要的。尽量美观，为此我们加了好多Form,同时利用图片作为label的背景，实现界面的整体美观。
  
  实验感想
  陈斌：这个实验可以说是我敲定代码行数最多的一个实验，他与记事本还不一样，记事本可以从网上找到相关性比较大的代码，修改起来比较容易，而这个
  程序网上真心找不到什么非常切合我们实验的代码。无数的timer之间的交叉，虽然在理论上应该不会影响彼此之间，可是实验表明如果有一个特别慢，整体会变得
  特别卡。然后我一遍遍的调试，改变一个个的timer的Interval，可以说。这所有的Interval都是我们一点点在自己的感觉上找到的参数，可能不是非常适合，
  但是都凝结我们辛勤的结晶。每天关灯之后编到电脑没电，连续4天才把这个程序的主体框架弄好，很累但是最终也是很开心。
  */
namespace 飞机大战
{
    public partial class MainForm : Form
    {
        int background;
        int score = 0;//记录总得分的一个变量；
        int totalCrashEnemyPlane = 0;//记录总的坠机数；
        int plane;
        int i = 0;//表示当前释放子弹的标号
        int j = 0;
        int bossBulletI = 0;//表示你你选中的飞机
        int bossBulletJ = 0;//表示可以看得见的子弹
        int bigBang = 3;//可以清除全图的大爆炸
        int tExplodeInterval = 0;
        int bossEndureBullet = 0;//boss可以接受的子弹数
        int life = 2;
        int fire = 0;//激发子弹数量
        int hit = 0;//命中子弹数量
        int boss = 0;//击毁boss数量
        Boolean mainrestart;//是否重新开始
        PictureBox[] myPlane = new PictureBox[3];//3个可供我方选择的飞机
        PictureBox[] myBullet = new PictureBox[10];//图中最多可以同时出现10个子弹
        PictureBox [] enemyPlane=new PictureBox [13];//图中最多可以同时出现13架敌机
        PictureBox[] bossplane = new PictureBox[3];//有3个随机出现的boss
        PictureBox[] bossBullet = new PictureBox[11];//boss也是最多同时发射11个子弹
        public int background_m//设立一个background的属性，可以从别的框引进来
        {
            set 
            {
                background = value;//set的函数
            }
        }
        public int plane_m//设立一个可以从从From输进来的Plane属性。
        {
            set
            {
                plane = value;//该属性只可以被写
            }
        }

        public Boolean restart//Boolean的Form属性。
        {
            get
            {
                return mainrestart;//仅仅有get函数。
            }
        }
         
        public MainForm()
        {
            InitializeComponent();
            System.Media.SoundPlayer music = new System.Media.SoundPlayer();
            music.SoundLocation = "新春序曲.wav";
            music.Load();
            music.PlayLooping();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            myPlane[0] = j10PictureBox;//初始化飞机数组
            myPlane[1] = j20PictureBox;
            myPlane[2] = j31PictureBox;
            myBullet[0] = myBulletPictureBox0;//初始化子弹数组。由于无法利用for循环，只能一个一个该
            myBullet[1] = myBulletPictureBox1;
            myBullet[2] = myBulletPictureBox2;
            myBullet[3] = myBulletPictureBox3;
            myBullet[4] = myBulletPictureBox4;
            myBullet[5] = myBulletPictureBox5;
            myBullet[6] = myBulletPictureBox6;
            myBullet[7] = myBulletPictureBox7;
            myBullet[8] = myBulletPictureBox8;
            myBullet[9] = myBulletPictureBox9;
            enemyPlane[0] = enemyPictureBox1;//初始化敌机数组
            enemyPlane[1] = enemyPictureBox2;
            enemyPlane[2] = enemyPictureBox3;
            enemyPlane[3] = enemyPictureBox4;
            enemyPlane[4] = enemyPictureBox5;
            enemyPlane[5] = enemyPictureBox6;
            enemyPlane[6] = pictureBox1;
            enemyPlane[7] = pictureBox2;
            enemyPlane[8] = pictureBox3;
            enemyPlane[9] = pictureBox4;
            enemyPlane[10] = pictureBox5;
            enemyPlane[11] = pictureBox6;
            enemyPlane[12] = pictureBox7;
            bossplane[0] = bossPictureBox1;//初始化boss数组
            bossplane[1] = bossPictureBox2;
            bossplane[2] = bossPictureBox3;
            bossBullet[0] = bossBulletPictureBox0;//初始化boss子弹的数组
            bossBullet[1] = bossBulletPictureBox1;
            bossBullet[2] = bossBulletPictureBox2;
            bossBullet[3] = bossBulletPictureBox3;
            bossBullet[4] = bossBulletPictureBox4;
            bossBullet[5] = bossBulletPictureBox5;
            bossBullet[6] = bossBulletPictureBox6;
            bossBullet[7] = bossBulletPictureBox7;
            bossBullet[8] = bossBulletPictureBox8;
            bossBullet[9] = bossBulletPictureBox9;
            bossBullet[10] = bossBulletPictureBox10;
            switch (background)//根据welcomeForm里面改变的值，设定背景
         {
            case 1: BackgroundImage = background1PictureBox.Image; background1PictureBox.Visible = true; break;
            case 2: BackgroundImage = background2PictureBox.Image; background2PictureBox.Visible = true; break;
            case 3: BackgroundImage = background3PictureBox.Image; background3PictureBox.Visible = true; break;
         }
            switch (plane)//根据welcomeForm里面改变的值，设定具体的飞机
         {
            case 1: myPlane[0].Visible = true;break;
            case 2: myPlane[1].Visible = true; break;
            case 3: myPlane[2].Visible = true; break;
         }
        }

        private void MainForm_KeyDown(object sender, KeyEventArgs e)//键盘按下时候的事件
        {//各个事件对应的up事件激发
            if (e.KeyCode.ToString() == "Up")
            {
                timerup.Start();
            }
            if (e.KeyCode.ToString() == "Down")
            {
                timerdown.Start();
            }
            if (e.KeyCode.ToString() == "Left")
            {
                timerleft.Start();
            }
            if (e.KeyCode.ToString() == "Right")
            {
                timerright.Start();
            }
            if (e.KeyCode.ToString() == "Space")
            {
                timermybullet.Start();//发子弹的事件激发
                timermybulletflying.Start();//子弹在空中飞行的事件激发
            }
            if (bigBangPictureBox.Visible && ((myPlane[plane - 1].Top >= bigBangPictureBox.Top && myPlane[plane - 1].Top <= (bigBangPictureBox.Top + bigBangPictureBox.Height) && (myPlane[plane - 1].Left + myPlane[plane - 1].Width) >= bigBangPictureBox.Left && myPlane[plane - 1].Left <= (bigBangPictureBox.Left + bigBangPictureBox.Width)) || ((myPlane[plane - 1].Top <= bigBangPictureBox.Top) && (myPlane[plane - 1].Top + myPlane[plane - 1].Height) >= bigBangPictureBox.Top && (myPlane[plane - 1].Left + myPlane[plane - 1].Width) >= bigBangPictureBox.Left && myPlane[plane - 1].Left <= (bigBangPictureBox.Left + bigBangPictureBox.Width))))
            {//选择在这里触发大爆炸增加事件的原因是，此处没有timer，如果在timer之中，会以为一个周期产生很多不可理解的事情
                bigBangPictureBox.Visible = false;//将补给箱的不可见。
                if (bigBangPictureBox.Top + bigBangPictureBox.Height >= this.ClientSize.Height)
                {
                    bigBangPictureBox.Top -= bigBangPictureBox.Height;
                }
                else
                {
                    bigBangPictureBox.Top += bigBangPictureBox.Height;
                }//这两个是为了让他移动一下位置，这样飞机就碰不到了。
                bigBang++;
                bigBangLabel.Text = "BigBang X " + bigBang.ToString();//显示BigBang的增加
            }//用来接触并且消

            if (e.KeyCode.ToString() == ("b") || e.KeyCode.ToString ()== ("B"))//触发大爆炸事件
            {
                if (bigBang != 0)
                {
                    int n;
                    Random random = new Random();
                    n = random.Next(4);//产生一个书籍随机选择的大爆炸的函数。
                    bigBang--;
                    bigBangLabel.Text = "BigBang X " + bigBang.ToString();//图中显示大爆炸的数量减少
                    switch (n)
                    {
                        case 0: moGuYunPictureBox.Image = Image.FromFile("蘑菇云1.jpg"); break;
                        case 1: moGuYunPictureBox.Image = Image.FromFile("蘑菇云2.jpg"); break;
                        case 2: moGuYunPictureBox.Image = Image.FromFile("蘑菇云3.jpg"); break;
                        case 3: moGuYunPictureBox.Image = Image.FromFile("蘑菇云4.jpg"); break;
                    }
                    moGuYunPictureBox.Visible = true;
                    myPlane[plane - 1].Visible = false;
                    myPlaneCrashTimer .Enabled  = false;//此期间让飞机无敌。
                    moGuYunTimer.Start();//开始蘑菇云的计时到时间让他消失。
            
                }
            }
        }

        private void MainForm_KeyUp(object sender, KeyEventArgs e)//当把键松开时激发相对应的事件
        {
            if (e.KeyCode.ToString() == "Up")
            {
                timerup.Stop(); 
            }
            if (e.KeyCode.ToString() == "Down")
            {
                timerdown.Stop();
            }
            if (e.KeyCode.ToString() == "Left")
            {
                timerleft.Stop();
            }
            if (e.KeyCode.ToString() == "Right")
            {
                timerright.Stop();
            }
            if (bigBangPictureBox.Visible && ((myPlane[plane - 1].Top >= bigBangPictureBox.Top && myPlane[plane - 1].Top <= (bigBangPictureBox.Top + bigBangPictureBox.Height) && (myPlane[plane - 1].Left + myPlane[plane - 1].Width) >= bigBangPictureBox.Left && myPlane[plane - 1].Left <= (bigBangPictureBox.Left + bigBangPictureBox.Width)) || ((myPlane[plane - 1].Top <= bigBangPictureBox.Top) && (myPlane[plane - 1].Top + myPlane[plane - 1].Height) >= bigBangPictureBox.Top && (myPlane[plane - 1].Left + myPlane[plane - 1].Width) >= bigBangPictureBox.Left && myPlane[plane - 1].Left <= (bigBangPictureBox.Left + bigBangPictureBox.Width))))
            {//和上一个放在key_down的原因一样
                bigBangPictureBox.Visible = false;
                if (bigBangPictureBox.Top + bigBangPictureBox.Height >= this.ClientSize.Height)
                {
                    bigBangPictureBox.Top -= bigBangPictureBox.Height;
                }
                else
                {
                    bigBangPictureBox.Top += bigBangPictureBox.Height;
                }
                bigBang++;
                bigBangLabel.Text = "BigBang X " + bigBang.ToString();
            }//用来接触并且消
            if (e.KeyCode.ToString() == "Space")
            {
                timermybullet.Interval = 20;//连续按和不连续按，一定时间发出的子弹数目不一样，就是改变了timermyBullet的Interval
                
                timermybullet.Stop();//按了Space之后子弹停止发射
            }
        }

        private void timerup_Tick(object sender, EventArgs e)//timer到时间之后激发的事件
        {
            if (myPlane[plane - 1].Top <= 10)//飞机如果没到顶，就将图片的位置加上十
            {
                myPlane[plane - 1].Top = 10;
            }
            else
            {
                myPlane[plane - 1].Top -= 10;
            } 
            
        }

        private void timerdown_Tick(object sender, EventArgs e)//timer到时间之后激发的事件
        {
            if (myPlane[plane - 1].Top >= this.ClientSize.Height - myPlane[plane - 1].Height - 10)///如果子弹没到底的时候每次讲飞机的位置减去十
            {
                myPlane[plane - 1].Top = this.ClientSize.Height - myPlane[plane - 1].Height - 10;
            }
            else
            {
                myPlane[plane - 1].Top += 10;
            }
        }

        private void timerleft_Tick(object sender, EventArgs e)
        {
            if (myPlane[plane - 1].Left <= 10)//如果飞机距离屏幕左端的距离不小于十的时候就让飞机向左移动10
            {
                myPlane[plane - 1].Left = 10;
            }
            else
            {
                myPlane[plane - 1].Left -= 10;
            } 
        }

        private void timerright_Tick(object sender, EventArgs e)
        {
            if (myPlane[plane - 1].Left >= this.ClientSize.Width - myPlane[plane - 1].Width - 10)//飞机的左侧小于屏幕的宽度减去飞机的宽度减去10的可以让他向右移动
            {
                myPlane[plane - 1].Left = this.ClientSize.Width - myPlane[plane - 1].Width - 10;
            }
            else
            {
                myPlane[plane - 1].Left += 10;
            } 
        }

        private void timermybullet_Tick(object sender, EventArgs e)
        {
            myBullet[i].Visible = true;//timer到了之后顺序的让一个子弹可以看得见。
            fire++;//统计总的子弹数目的一个变量
            myBullet[i].Top = myPlane[plane - 1].Top - myBullet[i].Height;//初始化子弹位置
            myBullet[i].Left = myPlane[plane - 1].Left + myPlane[plane - 1].Width / 2 - 3;
            timermybullet.Interval = 200;
            i++;
            if (i == 10)//是个子弹依次发了一个之后重新开始计数
            {
                i = 0;
            }
        }

        private void timermybulletflying_Tick(object sender, EventArgs e)//除了子弹的移动还可以用来打击敌方战机。
        {
            for (j = 0; j < 10; j++)//十个子弹一个循环
            {
                if (myBullet[j].Visible == true)//如果一个子弹可见，就让他移动
                {                    
                        myBullet[j].Top -= 20;
                    if (myBullet[j].Top <= 10)//如果到达了屏幕的顶部就让它重新回到一个位置，然后不可见。
                    {
                        myBullet[j].Top = 500;
                        myBullet[j].Visible = false;
                    }
                }
            }
        }

        private void timerEnemyPlane_Tick(object sender, EventArgs e)
        {
            int i;
            Random random1 = new Random();//随机需选择出现的位置
            do
            {
                Random random2 = new Random();//随机选择出现的飞机种类
                i = random2.Next(13);
            } 
            while (enemyPlane[i].Visible == true);//如果敌机可见就重新找
            enemyPlane[i].Visible = true;//找到这个不可见的飞机让他变得可见。
            enemyPlane[i].Top = 0;//初始化敌机出现在屏幕之中的位置
            enemyPlane[i].Left = random1.Next(20, this.ClientSize.Width - enemyPlane[i].Width) - 10;
        }

        private void timerEnemyPlaneMove_Tick(object sender, EventArgs e)//敌机移动的一个事件。
        {
            for (int i = 0; i < 13; i++)
            {
                if (enemyPlane[i].Visible)//对于可见的敌机执行以下的事件。
                {
                    if (enemyPlane[i].Top<= this.ClientSize.Height - enemyPlane[i].Height - 10)//如果没有到达底部就让他继续向下走。
                       enemyPlane[i].Top += 10;
                    else
                    {
                        enemyPlane[i].Visible = false;//如果到底就让他不可见。
                        enemyPlane[i].Top = 0;
                    }
                }
            }
        }

        private void timerEnemyPlaneCrash_Tick(object sender, EventArgs e)//敌机被我放子弹击中并且消失的事件
        {
            for (int n = 0; n < 10; n++)
            {
                if (myBullet[n].Visible)//对十个子弹之中可见的子弹执行以下的事件。
                {
                    for (int m = 0; m < 13; m++)
                    {
                        if (enemyPlane[m].Visible)//敌机必须可见
                        {
                            if (( myBullet[n].Top >= enemyPlane[m].Top && myBullet[n].Top <= (enemyPlane[m].Top + enemyPlane[m].Height) && (myBullet[n].Left + myBullet[n].Width) >= enemyPlane[m].Left && myBullet[n].Left <= (enemyPlane[m].Left + enemyPlane[m].Width)))
                            {//判断两个图片，是否相交
                                score += 100;//得分增加
                                hit++;//命中增加
                                totalCrashEnemyPlane++;//总的击毁敌机的数目增加;
                                scoreLabel.Text = "Score:" + score;//得分增加
                                enemyPlane[m].Visible = false;//击中之后敌机不可见
                                myBullet[n].Visible = false;//我方的子弹同样不可以见到
                                baoZhaPictureBox.Visible = true;//把爆炸换位动图只有前很短的时间有图。后面为空，但是占据时间，可以做出timer的效果。
                                timerInterval.Enabled = true;//可以控制出现爆炸图片的时间
                                baoZhaPictureBox.Top = enemyPlane[m].Top;//初始化图片的初始位置
                                baoZhaPictureBox.Left = enemyPlane[m].Left;                               
                            }
                        }
                    }//
                        if (bossBulletI <3&& (myBullet[n].Top >= bossplane[bossBulletI].Top && myBullet[n].Top <= (bossplane[bossBulletI].Top + bossplane[bossBulletI].Height) && (myBullet[n].Left + myBullet[n].Width) >= bossplane[bossBulletI].Left && myBullet[n].Left <= (bossplane[bossBulletI].Left + bossplane[bossBulletI].Width)))
                        {//判断是否击中boss;
                            bossEndureBullet++;//击中在boss上的子弹总数目
                            hit++;//命中加一
                            myBullet[n].Visible = false;
                            if (bossEndureBullet == 16)//每个boss可以挨打16下
                            {
                                score += 2000;//得分为2000
                                boss++;
                                scoreLabel.Text = "Score:" + score;
                                bossplane[bossBulletI].Visible = false;
                                bossPlaneLeftTimer.Stop();//让飞机自动向左移动
                                bossPlaneRightTimer .Stop ();//让飞机自动向右移动
                                bossBulletTimer.Interval  += 5;//以后让boss出现的速度变快
                                if (bossBulletFlyTimer.Interval>=10)
                                bossBulletFlyTimer.Interval -= 10;//这是最快的极限
                                if (timerEnemyPlaneMove.Interval >= 5)//设置一个子弹移动速度的极限
                                  timerEnemyPlaneMove.Interval  -= 5;
                                if (bossPlaneLeftTimer.Interval>2)//boss左移的极限
                                bossPlaneLeftTimer.Interval = bossPlaneLeftTimer.Interval - 2;
                                if (bossPlaneRightTimer.Interval > 2)
                                bossPlaneRightTimer.Interval = bossPlaneRightTimer.Interval -2;
                                for (int i = 0; i < 11; i++)
                                {
                                    bossBullet[i].Visible = false;//boss死后子弹全部消失。
                                }
                                baozhaPictrueBox2.Visible = true;//显示一个飞机炸毁的图片
                                timerInterval.Enabled = true;//控制这个爆炸图片出现的时间的长短的。
                                baozhaPictrueBox2.Top = myBullet[n].Top ;//初始化这个爆炸的位置的。
                                baozhaPictrueBox2.Left = myBullet[n].Left;
                                bossEndureBullet = 0;//将射中的变成0；
                                bossBulletI = 3;
                             }
                        }                     
                }
            }
        }

        private void timerBoss_Tick(object sender, EventArgs e)
        {
            if (bossplane [0].Visible ==false &&bossplane [1].Visible ==false &&bossplane [2].Visible ==false)//3架都不可见的时候激发出现的boss的事件
            {
                Random random2 = new Random();//随机选择出现的boss飞机种类
                i = random2.Next(3);
                bossplane[i].Visible = true;
                bossplane[i].Left = random2.Next(20, this.ClientSize.Width - bossplane[i].Width) - 10;
                bossPlaneLeftTimer.Start();//自动向左移动
                bossBulletTimer.Start();//自动发子弹
            }
        }

        private void buJiTimer_Tick(object sender, EventArgs e)
        {
            int randomInt;
            Random random = new Random();
            randomInt = random.Next(2);//让补给的产生随机。
            if (randomInt == 1)
            {
                bigBangPictureBox.Top = random.Next(20, this.ClientSize.Height - 20);//初始化补给箱的位置
                bigBangPictureBox.Left = random.Next(20, this.ClientSize.Width - 20);
                bigBangPictureBox.Visible = true;//使之可见
            }          
        }

        private void timerInterval_Tick(object sender, EventArgs e)
        {
            tExplodeInterval++;//这个是控制出现爆炸时间的一个timer
            if (tExplodeInterval ==7)
            {//这个触发7次之后让爆炸消失
                baoZhaPictureBox.Visible = false;
                baozhaPictrueBox2.Visible = false;
                timerInterval.Enabled = false;
                tExplodeInterval = 0;
            }
        }

        private void myPlaneCrashTimer_Tick(object sender, EventArgs e)//我放飞机坠毁的一个事件
        {
            for (int m = 0; m < 13; m++)
            {
                if (enemyPlane[m].Visible)//如果敌机可见
                {
                    if ((myPlane[plane - 1].Top >= enemyPlane[m].Top && myPlane[plane - 1].Top <= (enemyPlane[m].Top + enemyPlane[m].Height) && (myPlane[plane - 1].Left + myPlane[plane - 1].Width) >= enemyPlane[m].Left && myPlane[plane - 1].Left <= (enemyPlane[m].Left + enemyPlane[m].Width)) || ((myPlane[plane - 1].Top <= enemyPlane[m].Top) && (myPlane[plane - 1].Top + myPlane[plane - 1].Height) >= enemyPlane[m].Top && (myPlane[plane - 1].Left + myPlane[plane - 1].Width) >= enemyPlane[m].Left && myPlane[plane - 1].Left <= (enemyPlane[m].Left + enemyPlane[m].Width)))
                    {//判断我们是否相撞
                        enemyPlane[m].Visible = false;//相撞之后敌机消失
                        myPlane[plane - 1].Visible = false;//我方飞机消失
                        baoZhaPictureBox.Visible = true;//出现爆炸
                        timerInterval.Enabled = true;//控制爆炸时间timer运行
                        baoZhaPictureBox.Top = myPlane[plane - 1].Top;//初始化爆炸的位置
                        baoZhaPictureBox.Left = myPlane[plane - 1].Left;
                    }
                }
            }
            for (int m = 0; m < 3; m++)
            {
                if (bossplane[m].Visible)
                {
                    if ((myPlane[plane - 1].Top >= bossplane[m].Top && myPlane[plane - 1].Top <= (bossplane[m].Top + bossplane[m].Height) && (myPlane[plane - 1].Left + myPlane[plane - 1].Width) >= bossplane[m].Left && myPlane[plane - 1].Left <= (bossplane[m].Left + bossplane[m].Width)) || ((myPlane[plane - 1].Top <= bossplane[m].Top) && (myPlane[plane - 1].Top + myPlane[plane - 1].Height) >= bossplane[m].Top && (myPlane[plane - 1].Left + myPlane[plane - 1].Width) >= bossplane[m].Left && myPlane[plane - 1].Left <= (bossplane[m].Left + bossplane[m].Width)))
                    {//如若boss可见判断我们两个是否相撞
                        bossplane[m].Visible = false;//boss击毁
                        myPlane[plane - 1].Visible = false;//我方坠毁
                        baoZhaPictureBox.Visible = true;//出现爆炸图，同上
                        timerInterval.Enabled = true;//同上
                        baoZhaPictureBox.Top = myPlane[plane - 1].Top;//同上
                        baoZhaPictureBox.Left = myPlane[plane - 1].Left;
                    }//同上
                }
            }
            for (int m = 0; m < 11; m++)
            {
                if (bossBullet[m].Visible)
                {
                    if ((myPlane[plane - 1].Top >= bossBullet[m].Top && myPlane[plane - 1].Top <= (bossBullet[m].Top + bossBullet[m].Height) && (myPlane[plane - 1].Left + myPlane[plane - 1].Width) >= bossBullet[m].Left && myPlane[plane - 1].Left <= (bossBullet[m].Left + bossBullet[m].Width)) || ((myPlane[plane - 1].Top <= bossBullet[m].Top) && (myPlane[plane - 1].Top + myPlane[plane - 1].Height) >= bossBullet[m].Top && (myPlane[plane - 1].Left + myPlane[plane - 1].Width) >= bossBullet[m].Left && myPlane[plane - 1].Left <= (bossBullet[m].Left + bossBullet[m].Width)))
                    {//判断我方是否被boss的子弹击中
                        bossBullet[m].Visible = false;//同上
                        myPlane[plane - 1].Visible = false;//同上
                        baoZhaPictureBox.Visible = true;//同上
                        timerInterval.Enabled = true;//同上
                        baoZhaPictureBox.Top = myPlane[plane - 1].Top;
                        baoZhaPictureBox.Left = myPlane[plane - 1].Left;
                    }
                }
            }
            if (myPlane[plane - 1].Visible == false)//如果我方死亡
            {
                life --;//生命减少1
                lostLifeLabel.Visible = true;//出现一句话
                if (plane == 1)
                {//让飞机回到最底部。
                    myPlane[plane - 1].Top = myPlane[2].Top;
                    myPlane[plane - 1].Left = myPlane[2].Top;
                }
                else
                {
                    myPlane[plane - 1].Top = myPlane[plane - 2].Top;
                    myPlane[plane - 1].Left = myPlane[plane - 2].Top;
                }
                lostLifeTimer.Enabled = true;
                if (life >= 0)//如果还有生命。则让所有控件停止飞机进入一段时间的无敌。
                {
                    myPlaneCrashTimer.Stop();
                    timerup.Stop();
                    timerdown.Stop();
                    timerleft.Stop();
                    timerright.Stop();
                    timermybullet.Stop();
                    bossPlaneLeftTimer.Stop();
                    bossPlaneRightTimer.Stop();
                    lifeLabel.Text = "Life X " + life.ToString();
                    clear();
                    myPlane[plane - 1].Visible = true;
                    myPlaneCrashTimer.Start();
                }
                else
                {
                    myPlaneCrashTimer.Stop();
                    overForm aoverForm = new overForm();//游戏结束时建立一个overform的实例
                    aoverForm.score = score;//通过overform的属性，将游戏的统计信息传递过去
                    aoverForm.enermy = totalCrashEnemyPlane;
                    aoverForm.hit = hit;
                    aoverForm.fire = fire;
                    aoverForm.boss = boss;
                    aoverForm.ShowDialog();
                    if (aoverForm.restart == true)
                    {
                        //若实例aoverform的restart属性的返回值为真，则将本窗体的响应值赋为真，并关闭本窗体
                        mainrestart = true;
                        this.Close();
                    }
                    else
                    {
                        // //若实例aoverform的restart属性的返回值为假，则将本窗体的响应值赋为假，并关闭本窗体
                        mainrestart = false;
                        this.Close();
                    }
                }


            }
        }

        private void bossBulletTimer_Tick(object sender, EventArgs e)//boss发射子弹时候timer。
        {
            for (bossBulletI = 0; bossBulletI < 3; bossBulletI++)
                if (bossplane[bossBulletI].Visible == true)
                    break;//找出可见的飞机。
            if (bossBulletI < 3)
            {
                for (bossBulletJ = 0; bossBulletJ < 11; bossBulletJ++)
                {
                    if (bossBullet[bossBulletJ].Visible == false && bossplane[bossBulletI].Visible )
                    {//找到不可见的子弹，让他依次可以见到。然后初始化他的位置，让子弹移动的控件激发
                        bossBullet[bossBulletJ].Visible = true;
                        bossBullet[bossBulletJ].Top = bossplane[bossBulletI].Top + bossplane[bossBulletI].Height;
                        bossBullet[bossBulletJ].Left = bossplane[bossBulletI].Left+60;
                        bossBulletFlyTimer.Start();
                        break;
                    }

                }
            }
        }

        private void bossBulletFlyTimer_Tick(object sender, EventArgs e)//boss子弹飞行时的控件
        {
            int j;
            for (j = 0; j < 11; j++)
            {
                if (bossBullet[j].Visible == true)
                {
                    bossBullet[j].Top += 40;//对于可见的没到底的子弹让他移动，否则就让他到底小时不可见。
                    if (bossBulletI<3 && bossBullet[j].Top >= this.ClientSize.Height - bossBullet[j].Height - 10)
                    {
                        bossBullet[j].Top = bossplane[bossBulletI].Top + bossplane[bossBulletI].Height ;
                        bossBullet[j].Visible = false;                        
                    }
                }
            }
        }

        private void bossPlaneLeftTimer_Tick(object sender, EventArgs e)//boss向左移动时候触发的事件
        {
            if (bossBulletI < 3 && bossplane[bossBulletI].Visible )//还可以左移就左移否则便开始右移
            {
                if (bossplane[bossBulletI].Left >= this.ClientSize.Width - bossplane[bossBulletI].Width - 10)
                {
                    bossPlaneLeftTimer.Stop();
                    bossPlaneRightTimer.Start();
                }
                else
                {
                    bossplane[bossBulletI].Left += 30;
                }
            }
        }

        private void bossPlaneRightTimer_Tick(object sender, EventArgs e)//boss向右移动时候触发的事件
        {
            if (bossBulletI < 3 && bossplane[bossBulletI].Visible)
            {
                if (bossplane[bossBulletI].Left <= 10)//如果还可以向右移则右移否则，右移停止开始左移的控件
                {
                    bossPlaneRightTimer.Stop();
                    bossPlaneLeftTimer.Start();
                }
                else
                {
                    bossplane[bossBulletI].Left -= 30; 
                }
            }
        }
        private void clear()//将对方所有都清空的一个函数。
        {
            for (int i = 0; i < 13; i++)
            {
                enemyPlane[i].Visible = false;
            }
            for (int i = 0; i < 3; i++)
            {
                bossplane[i].Visible = false;
            }
            for (int i = 0; i < 11; i++)
            {
                bossBullet[i].Visible = false;
            }
            bossPlaneLeftTimer.Stop();
            bossPlaneRightTimer.Stop();
        }

        private void moGuYunTimer_Tick(object sender, EventArgs e)//发生大爆炸之后对应的timer
        {
            moGuYunPictureBox.Visible = false;
            myPlane[plane - 1].Visible = true;
            moGuYunTimer.Stop();//发生之后让这个timer停止
            clear();//清空所有。
            myPlaneCrashTimer.Start();//让飞机不在无敌
        }

        private void lostLifeTimer_Tick(object sender, EventArgs e)//lostLife那一句话对应的控件
        {
            lostLifeLabel.Visible = false;
            lostLifeTimer.Enabled = false;
        }
     
    }
}
