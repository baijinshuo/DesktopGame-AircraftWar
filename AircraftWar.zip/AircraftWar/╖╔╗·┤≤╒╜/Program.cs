﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace 飞机大战
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            splashForm asplashForm = new splashForm();
            asplashForm.ShowDialog();
            Application.Run(new WelcomeForm());
        }
    }
}
